package com.djcebul.vhs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VhsApplication {

	public static void main(String[] args) {
		SpringApplication.run(VhsApplication.class, args);
	}

}
